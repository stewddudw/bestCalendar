More Information button: 
To add a "More Information" custom HTML or PDF file, you can you the 'Upload File' button. Images in a HTML file must be uploaded by FTP and should be saved and link to the urls/urlImages folder.

Otherwise, images should be embedded into a PDF file.

To add a Link to an external HTML, YouTube, etc. instead of uploading a file, use the 'Link a URL' button.

PDF files: For embeded images you should try to reduce the size any pdf to save the time it takes to download the file by the user.
Example: The 02-03-2025.html file with the band images was opened in the Edge browser then: 
1. I printed to "Save as PDF"
2. Used 'more option' to Scale to 50% with no margins
3. The pdf was still over 3mbs
4. I then used the Free PDFgear program in Windows to open the pdf.
5. In the Tools Menu I used 'compress' to reduce the size to just 50kb.

https://www.pdfgear.com/

