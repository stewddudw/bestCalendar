More Information button: 
To add a "More Information" custom HTML or PDF file, you can you the 'Upload File' button. Images in a HTML file must be uploaded by FTP and should be saved and link to the eventImages/MoreInfoUrls folder.

Otherwise, images should be embedded into a PDF file.

To add a Link to an external HTML, YouTube, etc. instead of uploading a file, use the 'Link a URL' button.

help full tools:
Convert HTML files to PDF
https://chromewebstore.google.com/

Coverting from other formats;
https://www.pdfgear.com/

