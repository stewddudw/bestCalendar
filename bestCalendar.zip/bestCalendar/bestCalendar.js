//ASPX/VBscript Server-side Events Calendar ver01.001
localStorage.clear(); //remove all cached events items
let navigation = 0, extension = '', exampleDate = true; //change to false
let date2startOn = new Date(); //today's date

if (exampleDate==true){
  date2startOn='2026-04-02T00:00'; //example date
} else {
  date2startOn=new Date(); //today's date
}

window.onload = function() {
let eventDate = null,events,eventData,editMode = false,pw = null,startX,startY;
let id = function(id) { return document.getElementById(id); }; //avoid jQuery.noConflict() if using jQuery.

importData("events","bestCalendar.txt");
async function importData(category,fileName) {
  file = fileName + "?noCache=" + Math.random().toString(36).substr(2, 9);
  const response = await fetch(file)
  .then(response => {
    if (!response.ok) { throw new Error('Network response was not ok'); }
    return response.text();
  })
  .then(data => { localStorage.setItem(category, data); loadCalendar(); buttons();})
  .catch(error => { console.error('error fetching data:', error); });
}
const holidays = [ //note that some holidays can fall on different days each year.
  {hdate: "25-12",holiday: "Christmas"},{hdate: "31-12",holiday: "New Year's Eve"},
  {hdate: "01-01",holiday: "New Year's Day"},{hdate: "14-02",holiday: "Valentine's"},
  {hdate: "17-03",holiday: "St. Patrick's"},{hdate: "04-07",holiday: "Independence"},
  {hdate: "31-10",holiday: "Halloween"}]
/////////////////////////////////////////////////////////////////////////////////////////////////////
document.addEventListener('keydown', function(e) { Fkey(e) }); //F8 open editor or
id('editMobile').addEventListener('dblclick', function(e) { Fkey('F8') }); //(mobile) dblclick month name.

function Fkey(e) { //uploads and saves NewCalendar.txt to the server using the aspx file.
  if (e.key === 'F8' || e=='F8') { //if F8 already used by browser, change edit key here
    editMode = !editMode;
    id('editMode').style.display = id('editMode').style.display === 'block' ? 'none' : 'block';
  }
}

function getDayName(dateStr, locale) { //adds short day name (Mon,Tue...) to portrait mobile.
  return  new Date(dateStr).toLocaleDateString(locale,{weekday:'short'});        
}

const weekdays = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
/////////////////////////////////////////////////////////////////////////////////////////////////////
function loadCalendar() {
  events = localStorage.getItem("events") ? JSON.parse(localStorage.getItem("events")) : [];
  const dt = new Date(date2startOn); // date2startOn value is at line 4.

  if (navigation != 0) { dt.setMonth(new Date().getMonth() + navigation); }
  const [month, day, year] = [dt.getMonth(), dt.getDate(), dt.getFullYear()];
  id('month').innerText = `${dt.toLocaleDateString("en-us", { month: "long", })} ${year}`;
  
  id('calendar').innerHTML = "";
  const dayInMonth = new Date(year, month + 1, 0).getDate();
  const firstDay = new Date(year, month, 1);
  const dateString = firstDay.toLocaleDateString("en-us",{weekday:"long",year:"numeric",month:"numeric",day:"numeric",});
  const emptyDays = weekdays.indexOf(dateString.split(",")[0]);

  for (let i = 1; i <= dayInMonth + emptyDays; i++) {
    const dayBox = Object.assign(document.createElement("div"),{ className:"day" });
    const monthVal = month + 1 < 10 ? "0" + (month + 1) : month + 1; //format 1-9 with a leading zero.
    const dateVal = i - emptyDays < 10 ? "0" + (i - emptyDays) : i - emptyDays; 
    const dateText = `${monthVal}-${dateVal}-${year}`;
    const holidayText = `${dateVal}-${monthVal}`;
    
    if (i > emptyDays) {
      dayBox.innerText = (i - emptyDays).toString().padStart(2, '0');
      const dayName = getDayName(dateText,'en-us');
      const dayNum = dayBox.innerHTML;
      dayBox.innerHTML = "<span class='dayNum'>" + dayNum + "</span><span class='dayName'>" + dayName + "</span>";

      const Event = events.find((e) => e.date == dateText);
      const holiday = holidays.find((e) => e.hdate == holidayText);
      if (i - emptyDays === day && navigation == 0) { dayBox.id = "currentDay"; }

      if (Event) {
        const eventTitleDiv = Object.assign(document.createElement("div"),{ className:"eventTitleDiv" });
        eventTitleDiv.innerText = Event.title;
        dayBox.appendChild(eventTitleDiv);

        const eventDiv = Object.assign(document.createElement("div"),{ className:"event" });
        eventDiv.innerText = Event.event;
        dayBox.appendChild(eventDiv);
        
        const eventTimeDiv = Object.assign(document.createElement("div"),{ className:"eventTimeDiv" });
        eventTimeDiv.innerHTML = "</span><span class='dayName'>" + dayName + "</span>" + Event.time;
        dayBox.appendChild(eventTimeDiv);
      }
      if (holiday) {
        const eventDiv = Object.assign(document.createElement("div"),{ className:"holiday" });
        eventDiv.innerText = holiday.holiday;
        dayBox.appendChild(eventDiv);
        eventDiv.parentElement.classList.add("holidayDiv");
      }
      dayBox.addEventListener("click", () => { showEvent(dateText); });
    } else {
      dayBox.classList.add("plain");
    }
    id('calendar').append(dayBox);
  }
} //end loadCalendar
/////////////////////////////////////////////////////////////////////////////////////////////////////
function buttons() {
  id('btnBack').addEventListener("click", () => { navigation--; loadCalendar(); });
  id('btnNext').addEventListener("click", () => { navigation++; loadCalendar(); });
  id('btnClose').addEventListener("click", closeModal);

  id('btnSave').addEventListener("click", function () {
    if (mTitle.value) {
      const dataFromStorage = JSON.parse(localStorage.getItem('events'));
      const index = dataFromStorage.findIndex(d => d.date === eventDate);
      if(index > -1) { //edit event.
        let value = {date:eventDate,title:mTitle.value.trim(),event:mText.value.trim(),time:mTime.value.trim()}
        dataFromStorage[index] = value
        localStorage.setItem("events", JSON.stringify(dataFromStorage)); //only saved locally.
      } else { //add a new event.
        events.push({date:eventDate,title:mTitle.value.trim(),event:mText.value.trim(),time:mTime.value.trim(),});
        localStorage.setItem("events", JSON.stringify(events)); //only saved locally.
      }
    authorization(null,eventDate,'save'); closeModal(); //server update then close.
    }
  });
  
  id('btnDelete').addEventListener("click", function () {
    events = events.filter((e) => e.date !== eventDate);
    localStorage.setItem("events", JSON.stringify(events)); //only saved locally.
    authorization(null,eventDate,'delete'), closeModal(); //server delete event then close.
  });
} //end buttons
/////////////////////////////////////////////////////////////////////////////////////////////////////
id('btnUploadImage').addEventListener('click', (e) => {
    if (exampleDate == true) { alert('disabled in Demo mode'); return; }
    url = "aspx/ImageUpload.aspx?eventDate=" + id('mDate').innerText + '&pw=' + pw;  
    document.getElementById('iframeUpload').src=url;
    id('iframeUpload').style.display='block';
});

id('btnUploadFile').addEventListener('click', (e) => {
  if (exampleDate == true) { alert('disabled in Demo mode'); return; }
    url = "aspx/FileUpload.aspx?eventDate=" + id('mDate').innerText + '&pw=' + pw;
    document.getElementById('iframeUpload').src=url;
    id('iframeUpload').style.display='block';
});

/////////////////////////////////////////////////////////////////////////////////////////////////////
const modal = document.querySelector("#modal");
const viewEventForm = document.querySelector("#modalTable");

function showEvent(dateText) {
  eventDate = dateText;
  const Event = events.find((e) => e.date == dateText);
  if (editMode==false) { //show large poster-image of the Event.
    if (Event) { loadImage(eventDate,'eventImage','none'); return; }   
  } else {
    if (Event) { //edit the Event.
      mTitle.value = Event.title; mText.value = Event.event; mTime.value = Event.time;
      id('mDate').innerText = dateText;
      loadImage(eventDate,'uploadedImage','none'); 
    } else { //add a new Event.
      mTitle.value = ""; mText.value = ""; mTime.value = "";
      id('mDate').innerText = dateText;
      if (mTitle.value =='') {
        id('btnUploadImage').disabled=true; id('btnUploadFile').disabled=true;
      } else {
        id('btnUploadImage').disabled=false; id('btnUploadFile').disabled=false;
      }
      id('uploadedImage').src='eventImages/defaultEvent.jpg';
    }
    viewEventForm.style.display = "block"; modal.style.display = "block";
   }
} // end showEvent
/////////////////////////////////////////////////////////////////////////////////////////////////////
function loadImage(eventDate,el,display) {
  fetch('aspx/ImageExists.aspx?filename=' + eventDate) //check if image is in eventImages folder.
    .then(response => { return response.text() })
    .then(data => { id(el).src=data; id('imageDiv').style.display=display;})

   fetch('aspx/UrlExists.aspx?filename=' + eventDate) //check if matching file is in urls folder.
    .then(response => { return response.text() })
    .then(data => {
      if (data == "") { 
        id('urlBtn').style.display='none'; //don't show the 'More Information' Button.
      } else {
        id('urlBtn').style.display='block';
      }
      if (data == "html") { extension = "html"; }
      if (data == "pdf") { extension = "pdf"; }
    })
}

id('eventImage').onload = () => { 
  id('imageDiv').style.display='block';
  var items = Array('rotate360','slideright','rotate360','slideleft','slidebottom');
  var item = items[Math.floor(Math.random()*items.length)]; //random animation (rotate360 has better chance).
  id('eventImage').style.animation = item + ' 0.5s';
}

function authorization(pw,eDay,action) { //authorization required for server-side.
  pw = prompt(""); 
  if (pw === null) { return; //prompt was cancelled.
  } else {
    if (exampleDate == true) { alert('data not saved in demo version'); return; }
    eventData = localStorage.getItem("events"); //console.log(eventData);
    url = "aspx/updateEvents.aspx?pw=" + pw + "&eventData=" + eventData + '&filename=' + eDay + '&action=' + action;
    window.open(url, '_blank'); //console.log(url);
  }
}
function closeModal() {
  id('uploadedImage').src = "images/loading.gif"; //reset default image
  viewEventForm.style.display = "none";  modal.style.display = "none";
  id('btnUploadImage').disabled=false; id('btnUploadFile').disabled=false;
  eventDate = null; loadCalendar(); //update any changes
}
function closeImage() { id('eventImage').style.animation = 'rotate360r 0.5s'; }

id('eventImage').addEventListener('animationend', () => {
  if (id('eventImage').style.animationName  == 'rotate360r') { id('imageDiv').style.display='none'; }
});

function pinchOut() {
  appliedScale = 1 - Math.random()*0.01; //reset pinch zoom
  document.querySelector('meta[name="viewport"]').setAttribute('content', "width=device-width, initial-scale=" + appliedScale);
}
/////////////////////////// Mobile touch events /////////////////////////////////////////////////////
let scaling=false;
id('urlBtn').addEventListener("mousedown",(e)=>{ url = 'eventImages/MoreInfoUrls/' + eventDate + '.' + extension;  window.open(url, '_blank'); });
id('imageDiv').addEventListener("mouseup",(e)=>{ if (e.target.id != 'urlBtn') { closeImage(); pinchOut();} });
id('imageDiv').addEventListener('touchstart',(e) => { if (e.touches.length === 2) { scaling = true;} }); 
id('imageDiv').addEventListener('touchmove',(e) => { if (scaling == false) { e.preventDefault();} });
id('imageDiv').addEventListener("touchend",(e)=>{ scaling = false; });
} //end window onload