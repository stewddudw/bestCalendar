﻿<%@ Page Language="VB" AutoEventWireup="false" CodeFile="ImageUpload.aspx.vb" Inherits="VB" %>

<!DOCTYPE html>
<html lang="en">
<meta charset="UTF-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<head runat="server">
<title>upload Event Image</title>
<style>
body { background: OldLace;}
.btn { width: 120px; height: 30px;}
.img1, .btnClose { position: absolute; margin: 0 auto; left: 0; right: 0;}
.img1 { background: black url('../images/loading.gif') no-repeat center center;}
.btnClose { bottom: 0; height: 30px;}
</style>
</head>

<body>
  <asp:label ID="dateLabel" runat="server" />
  <form id="form1" runat="server">
  <asp:FileUpload ID="FileUpload1" runat="server" accept=".jpg,.png" onchange="ShowPreview(this)" />
  <asp:Button ID="btnUpload" Text="Upload" runat="server" CssClass="btn" OnClick="UploadFile" />
  <hr />
  <asp:Image ID="Image1" runat="server" CssClass="img1" Height="400" Width="280" />
  </form>
  <button class="btnClose" onmousedown="closeframe()">Close</button>
</body>
</html>

<script>
  let file='', id = function(id) { return document.getElementById(id); };
  function ShowPreview(input) {
    var reader = new FileReader();
    reader.readAsDataURL(id("FileUpload1").files[0]);

    reader.onload = function (e) {
      id("Image1").src = e.target.result;
      id("Image1").onload = () => {
        w=id("Image1").naturalWidth ;h=id("Image1").naturalHeight;
        if (w !==540 && h !=800) { //change default image poster size here
          alert('image dimensions must be 540 x 800'); id('btnUpload').disabled=true;
        } else {
          id('btnUpload').disabled=false;
        }
      }
    }
  } //end ShowPrevioew
<%
  dim eventDate as String
  eventDate = Request.QueryString("eventDate")
  dateLabel.Text = eventDate
%>
loadImage('Image1'); 
    
function loadImage(el) {
  fetch('ImageExists.aspx?filename=' + '<%=eventDate%>')
  .then(response => { return response.text() })
  .then(data => { id(el).src="../" + data; file=data})
}
  
id('btnUpload').disabled=true;
  
function closeframe() {
  parent.document.getElementById('uploadedImage').src = file;
  parent.document.getElementById('iframeUpload').style.display = 'none';
}
</script>