﻿<%@ Page Language="VB" AutoEventWireup="false" CodeFile="FileUpload.aspx.vb" Inherits="VB" %>

<!DOCTYPE html>
<html lang="en">
<meta charset="UTF-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<head runat="server">
<title>upload File</title>
<style>
body { 
  background: OldLace;
}
.btn {
  width: 120px;
  height: 30px;
}
.btnClose { 
 position: absolute;
 margin: 0 auto;
 left: 0;
 right: 0;
 bottom: 0;
 height: 30px;
}
.txtBox {
  margin-top: 20px;
  height: 30px;
  width: 380px;
  font-size: 15px;
}
.btnLink {
  float: left;
  width: 120px;
  height: 30px;
}
.btnDelete {
  float: right;
  width: 120px;
  height: 30px;
  
}
</style>
</head>

<body>
  <asp:label ID="dateLabel" runat="server" />
  <form id="form1" runat="server">
    <asp:FileUpload ID="FileUpload1" runat="server" accept=".html,.pdf" onchange="enableUploadBtn(this)" />
    <asp:Button ID="btnUpload" Text="Upload" runat="server" CssClass="btn" OnClick="UploadFile" />
    <asp:TextBox ID="txtBox" placeholder="https://website/folder/file.html" mode="Multiline" runat="server" CssClass="txtBox" />
    <p><b>More Information Button:</b></p>
    <p>To add a custom html or pdf file to the 'More Information' button, select the file then click the 'Upload' button.</p>
    <p>Note: if you upload a custom HTML file, any images must be uploaded via ftp to the urls images folder (e.g. 'images/image01.jpg')</p>

    <p>Or to link a URL (YouTube, html, etc.) type the full url address into the text box then click 'Link a URL'.</p>
    <p>This will overide any uploaded file (leave the text box blank otherwise).</p>
    <asp:Button ID="btnURL" Text="Link a URL" runat="server" CssClass="btnLink" OnClick="LinkURL" />
    <asp:Button ID="btnDelete" Text="Delete File or Link " runat="server" CssClass="btnDelete" 
    OnClick="DeleteFile" OnClientClick="return confirm('Are you sure you want to delete this record?');" />
    <button class="btnClose" onmousedown="closeframe()">Close</button>
  </form>
</body>
</html>

<script>
  let file='', id = function(id) { return document.getElementById(id); };
  function enableUploadBtn(input) { id('btnUpload').disabled=false; }

<%
  dim eventDate as String
  eventDate = Request.QueryString("eventDate")
  dateLabel.Text = eventDate
%>
  
id('btnUpload').disabled=true;
  
function closeframe() {
  parent.document.getElementById('iframeUpload').style.display = 'none';
}
</script>