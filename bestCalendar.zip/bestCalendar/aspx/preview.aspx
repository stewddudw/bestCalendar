<%@ Page Language='VB' Debug="true" %>

<!DOCTYPE html>
<html lang="en">

<meta charset="UTF-8" />
<meta content="IE=edge" http-equiv="X-UA-Compatible" />

<head runat="server">
<title>upload Event Image</title>
<style>
body {
	background: OldLace;
  font-size: 32px;
}
.table {
  margin: 50px auto;
  width: 80%;
  height: 200px;
  BORDER: 2px solid red;
}
.table td {
  text-align: center;
  padding: 10px;
}
.btnClose {
 margin-top: 50px;
	width: 300px;
	height: 100px;
  font-size: 28px;
}
</style>
</head>

<body>

<table class="table">
  <tr>
    <td>This is a Preview. You cannot save event to the server 
    with this version.</td>
  </tr>
  <tr>
    <td><button id="closeBtn" class="btnClose" onmousedown="closeframe()">Close
    </button></td>
  </tr>
</table>
<script>
  

function closeframe() {
  if (window.location === window.parent.location) { 
    window.close();
  } else {
    parent.document.getElementById('iframeUpload').style.display = 'none';
  }
}
</script>

</body>

</html>
