<%@ Page Language='VB' Debug="true" %>

<script runat="server">
Sub Page_Load (Sender As Object, e As EventArgs)

  dim file, filename, fs
  file = Request.QueryString("filename")
  ''more information button points to the html files you custon make in this folder
  filename = Server.MapPath("../eventImages/MoreInfoUrls/") & file
  
  fs=Server.CreateObject("Scripting.FileSystemObject")
  
  if fs.FileExists(filename & ".html") then response.write ("html")
  if fs.FileExists(filename & ".pdf") then response.write ("pdf")
    
End Sub

</script>

