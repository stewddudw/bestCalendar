<%@ Page Language='VB' Debug="true" %>

<script runat="server">
Sub Page_Load (Sender As Object, e As EventArgs)

  dim file, filename, fs
  file = Request.QueryString("filename")
  filename = Server.MapPath("../eventImages/") & file
  
  fs=Server.CreateObject("Scripting.FileSystemObject")
  
  if fs.FileExists(filename & ".jpg") then
    response.write ("eventImages/" & file  & ".jpg")
  else if fs.FileExists(filename & ".png")
    response.write ("eventImages/" & file  & ".png")
  else
    response.write ("eventImages/defaultEvent.jpg")
  end if
    
End Sub

</script>

