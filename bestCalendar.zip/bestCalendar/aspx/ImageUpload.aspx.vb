﻿Imports System.IO

Partial Class VB
    Inherits System.Web.UI.Page
    
    Sub Page_Load(ByVal Sender As Object, ByVal E As EventArgs) Handles Me.Load
        Dim eventDate
        eventDate = Request.QueryString("eventDate")
        dateLabel.Text = eventDate
    End Sub
    
    Protected Sub UploadFile(sender As Object, e As EventArgs)
    
        Dim eventDate
        eventDate = Request.QueryString("eventDate")
    
        Dim folderPath As String = Server.MapPath("../eventImages/")

        'Check whether Directory (Folder) exists.
        If Not Directory.Exists(folderPath) Then
            'If Directory (Folder) does not exists. Create it.
            Directory.CreateDirectory(folderPath)
        End If

        Dim extension As String = System.IO.Path.GetExtension(FileUpload1.PostedFile.FileName)
        FileUpload1.SaveAs(folderPath & eventDate & extension)
        
        Image1.ImageUrl = "../eventImages/" & eventDate & extension
        dateLabel.Text = dateLabel.Text & " upload success"
        
    End Sub

End Class


