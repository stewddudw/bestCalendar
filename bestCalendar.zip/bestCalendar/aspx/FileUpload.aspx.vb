﻿Imports System.IO

Partial Class VB
  Inherits System.Web.UI.Page
  Dim eventDate
  Dim folderPath As String = Server.MapPath("../eventImages/MoreInfoUrls/")
  Dim pattern As String
'''''''''''''''''''''''''''''''''''''''''''''''''''
  Sub Page_Load(ByVal Sender As Object, ByVal E As EventArgs) Handles Me.Load
    eventDate = Request.QueryString("eventDate")
    pattern = eventDate & ".*"
    dateLabel.Text = eventDate
  End Sub
''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
  Protected Sub UploadFile(sender As Object, e As EventArgs)
     If FileUpload1.PostedFile.FileName = "" Then Exit Sub

    'Check whether Directory (Folder) exists.
    If Not Directory.Exists(folderPath) Then
        Directory.CreateDirectory(folderPath) 'If Directory (Folder) does not exists. Create it.
    End If
    
    For Each file In System.IO.Directory.GetFiles(folderPath, pattern)
      System.IO.File.Delete(file) 'delete any files with the same name
    Next

    Dim extension As String = System.IO.Path.GetExtension(FileUpload1.PostedFile.FileName)

    FileUpload1.SaveAs(folderPath & eventDate & extension)
    dateLabel.Text = dateLabel.Text & " upload success"
  End Sub
'''''''''''''''''''''''''''''''''''''''''''''''''''
  Protected Sub LinkURL(sender As Object, e As EventArgs)
    Dim URL As String = txtBox.Text
    
    If URL ="" Then
      Response.Write("<script language=""javascript"">alert('There is no URL text in the text box!');</script>")
      Exit Sub
    End IF
    
    If  URL.Substring(0, 4) <> "http" Then
      Response.Write("<script language=""javascript"">alert('URL must start with http:// or https://');</script>")
      Exit Sub
    End IF
    
    Dim html As String = "<meta http-equiv='refresh' content='0; url=" & URL & "' />"
    Dim fileName As String = eventDate & ".html"
    Dim filePath As String = folderPath & fileName
    Dim objReader As StreamWriter = Nothing
    Try
      If File.Exists(filePath) Then DeleteFile(sender,e) ''File.Delete(filePath)
      objReader = New StreamWriter(filePath)
      objReader.Write(html)
    Finally
      objReader.Close()
    End Try
    ''Response.Redirect(fileName)
  End Sub
'''''''''''''''''''''''''''''''''''''''''''''''''''
  Protected Sub DeleteFile(sender As Object, e As EventArgs)
    For Each file In System.IO.Directory.GetFiles(folderPath, pattern)
      System.IO.File.Delete(file) 'delete any files with the same name
    Next
    
    Response.Write("<script language=""javascript"">alert('file and/or Link deleted');</script>")
  End Sub
'''''''''''''''''''''''''''''''''''''''''''''''''''

End Class


