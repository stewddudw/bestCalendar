<%@ Page Language='VB' Debug="true" %>

<script runat="server">
Sub Page_Load (Sender As Object, e As EventArgs)
  dim password : password= "zzz" ''CHANGE THE PASSWORD HERE !!
  dim eventData, filename, pw, action, file2delete, image2delete, fs
 
  eventData = Request.QueryString("eventData")
  filename = Request.QueryString("filename")
  pw = Request.QueryString("pw")
  action = Request.QueryString("action")
  
  image2delete = Server.MapPath("../eventImages/eventImages/") & filename 
  file2delete = Server.MapPath("../eventImages/MoreInfoUrls/") & filename 
  
  if pw = password then
    if filename <> "" and action = "delete" then
      fs=Server.CreateObject("Scripting.FileSystemObject")

      if fs.FileExists(image2delete & ".jpg") then fs.DeleteFile(image2delete & ".jpg")
      if fs.FileExists(image2delete & ".png") then fs.DeleteFile(image2delete & ".png")
      
      if fs.FileExists(file2delete & ".pdf") then fs.DeleteFile(file2delete & ".pdf")
      if fs.FileExists(file2delete & ".html") then fs.DeleteFile(file2delete & ".html")
    end if
  
    if eventData > "" then
      IO.File.WriteAllText(Server.MapPath("../bestCalendar.txt"),eventData)
      response.write ("The following events were written to the bestCalendar.txt file on the server: " + eventData)
    end if
  else
    response.write ("You don't have permission to save this page.")
  end if  

End Sub

</script>

